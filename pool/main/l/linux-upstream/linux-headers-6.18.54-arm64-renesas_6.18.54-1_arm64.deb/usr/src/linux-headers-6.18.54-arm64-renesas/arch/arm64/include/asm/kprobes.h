/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * arch/arm64/include/asm/kprobes.h
 *
 * Copyright (C) 2013 Linaro Limited
 */

#ifndef _ARM_KPROBES_H
#define _ARM_KPROBES_H

#include <asm-generic/kprobes.h>

#ifdef CONFIG_KPROBES
#include <linux/types.h>
#include <linux/ptrace.h>
#include <linux/percpu.h>

#define __ARCH_WANT_KPROBES_INSN_SLOT
#define MAX_INSN_SIZE			2

#define flush_insn_slot(p)		do { } while (0)
#define kretprobe_blacklist_size	0

#include <asm/probes.h>

struct prev_kprobe {
	struct kprobe *kp;
	unsigned int status;

	/*
	 * The original DAIF state of the outer kprobe, saved here before
	 * a nested kprobe overwrites kcb->saved_irqflag during reentry.
	 */
	unsigned long saved_irqflag;
};

/* per-cpu kprobe control block */
struct kprobe_ctlblk {
	unsigned int kprobe_status;
	unsigned long saved_irqflag;
	struct prev_kprobe prev_kprobe;
};

void arch_remove_kprobe(struct kprobe *);
int kprobe_fault_handler(struct pt_regs *regs, unsigned int fsr);
void __kretprobe_trampoline(void);
void __kprobes *trampoline_probe_handler(struct pt_regs *regs);

#endif /* CONFIG_KPROBES */

int __kprobes kprobe_brk_handler(struct pt_regs *regs,
				 unsigned long esr);
int __kprobes kprobe_ss_brk_handler(struct pt_regs *regs,
				 unsigned long esr);
int __kprobes kretprobe_brk_handler(struct pt_regs *regs,
				 unsigned long esr);

#endif /* _ARM_KPROBES_H */
